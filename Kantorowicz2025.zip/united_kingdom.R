##### UK ##### UK ##### UK ##### UK ##### UK ##### UK
##### UK ##### UK ##### UK ##### UK ##### UK ##### UK
##### UK ##### UK ##### UK ##### UK ##### UK ##### UK

# Load the United Kingdom dataset

uk <- read.csv("data/united_kingdom_survey.csv")

# Remove incomplete surveys

uk <- uk %>% filter(progress==100, finished==1)

# Count number of distinct responseid

n_distinct(uk$ID[!is.na(uk$selected)])


# Transform variables into factors and reorder features

uk$Terrorist.tactic2 <- factor(uk$Terrorist.tactic, levels = c("Stabbing", "Vehicle-ramming attack", 
                                                                               "Shooting", "Non-suicidal bombing", 
                                                                               "Suicidal bombing"))

uk$Motivation.for.the.terrorist.attack2 <- factor(uk$Motivation.for.the.terrorist.attack, levels = c("Right-wing extremism", "Jihadism"))
uk$Affiliation.of.the.terrorist <- factor(uk$Affiliation.of.the.terrorist)
uk$Legal.status.of.the.terrorist <- factor(uk$Legal.status.of.the.terrorist)
uk$Probability.of.the.attack <- factor(uk$Probability.of.the.attack)
uk$Number.of.deaths <- factor(uk$Number.of.deaths)

### AMCE

uk_amce <- cregg::amce(uk, 
                       selected ~ 
                       Affiliation.of.the.terrorist + 
                       Legal.status.of.the.terrorist + 
                       Motivation.for.the.terrorist.attack2 + 
                       Probability.of.the.attack +
                       Terrorist.tactic2*Number.of.deaths, 
                       id = ~ID)

# Transformation of the AMCE object

uk_amce_df <- as.data.frame(uk_amce)

uk_amce_df <- uk_amce_df %>% rename(term=level)
uk_amce_df <- uk_amce_df %>% rename(conf.low=lower)
uk_amce_df <- uk_amce_df %>% rename(conf.high=upper)

uk_amce_df$conf.low <- na.fill0(uk_amce_df$conf.low, 0)
uk_amce_df$conf.high <- na.fill0(uk_amce_df$conf.high, 0)

# Creating graph

# Severity

uk_amce_df_severity <- uk_amce_df %>% filter(feature=="Number.of.deaths")

loadfonts()

severity_plot <- ggcoef(uk_amce_df_severity, vline_color = "black", conf.int = TRUE,
                        mapping = aes(x = estimate, y = term), size = 4,
                        vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                        sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman",size=25)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(0, 0.40) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_amce_df_severity, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=5, check_overlap = TRUE, 
            vjust = -1.5)

# Probability

uk_amce_df_prob <- uk_amce_df %>% filter(feature=="Probability.of.the.attack")

prob_plot <- ggcoef(uk_amce_df_prob, vline_color = "black", conf.int = TRUE,
                    mapping = aes(x = estimate, y = term), size = 4,
                    vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                    sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman", size=25)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(0, 0.40) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_amce_df_prob, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=5, check_overlap = TRUE, 
            vjust = -1.5)

#### FIGURE 2 PANEL A

ggsave(severity_plot,
       file = "figures/figure2panelA.png",
       width = 5, height = 5, dpi = 350, units = "in", device='png')

#### FIGURE 2 PANEL B

ggsave(prob_plot,
       file = "figures/figure2panelB.png",
       width = 5, height = 5, dpi = 350, units = "in", device='png')


# Terror tactic

uk_amce_df_tactic <- uk_amce_df %>% filter(feature=="Terrorist.tactic2")

tactic_plot <- ggcoef(uk_amce_df_tactic, vline_color = "black", conf.int = TRUE,
                      mapping = aes(x = estimate, y = term), size = 4,
                      vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                      sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman", size=20)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(-0.005, 0.2) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_amce_df_tactic, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=4.5, check_overlap = TRUE, 
            vjust = -1.0)

# Motivation 

uk_amce_df_motivation <- uk_amce_df %>% filter(feature=="Motivation.for.the.terrorist.attack2")

uk_amce_df_motivation <- uk_amce_df_motivation %>% mutate(term=ifelse(term=="Right-wing extremism", "Right-wing extr.", "Jihadism"))

motivation_plot <- ggcoef(uk_amce_df_motivation, vline_color = "black", conf.int = TRUE,
                          mapping = aes(x = estimate, y = term), size = 4,
                          vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                          sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman", size=20)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(-0.005, 0.2) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_amce_df_motivation, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=4.5, check_overlap = TRUE, 
            vjust = -1.0)

# Affiliation

uk_amce_df_affiliation <- uk_amce_df %>% filter(feature=="Affiliation.of.the.terrorist")

uk_amce_df_affiliation <- uk_amce_df_affiliation %>% mutate(term=ifelse(term=="Lone actor - operating alone",  "Lone actor", "Member of a terror cell"))

affiliation_plot <- ggcoef(uk_amce_df_affiliation, vline_color = "black", conf.int = TRUE,
                           mapping = aes(x = estimate, y = term), size = 4,
                           vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                           sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman", size=20)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(-0.005, 0.2) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_amce_df_affiliation, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=4.5, check_overlap = TRUE, 
            vjust = -1.0)

# Status

uk_amce_df_legal_status <- uk_amce_df %>% filter(feature=="Legal.status.of.the.terrorist")

legal_status_plot <- ggcoef(uk_amce_df_legal_status, vline_color = "black", conf.int = TRUE,
                            mapping = aes(x = estimate, y = term), size = 4,
                            vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                            sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman", size=20)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(-0.005, 0.2) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_amce_df_legal_status, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=4.5, check_overlap = TRUE, 
            vjust = -1.0)

#### FIGURE 4 PANEL A

ggsave(legal_status_plot,
       file = "figures/figure4panelA.png",
       width = 5, 
       height = 5, 
       dpi = 350, 
       units = "in", 
       device='png')

#### FIGURE 5 PANEL A

ggsave(affiliation_plot,
       file = "figures/figure5panelA.png",
       width = 6, 
       height = 5, 
       dpi = 350, 
       units = "in", 
       device='png')

#### FIGURE 6 PANEL A

ggsave(tactic_plot,
       file = "figures/figure6panelA.png",
       width = 6, 
       height = 5, 
       dpi = 350, 
       units = "in", 
       device='png')

#### FIGURE 8 PANEL A

ggsave(motivation_plot,
       file = "figures/figure8panelA.png",
       width = 5, 
       height = 5, 
       dpi = 350, 
       units = "in", 
       device='png')







###### Sample including chemical attack ###### Sample including chemical attack ######
###### Sample including chemical attack ###### Sample including chemical attack ######
###### Sample including chemical attack ###### Sample including chemical attack ######

# Loading data from a csv file

uk_chemical <- read.csv("data/united_kingdom_chemical_survey.csv")

# Remove incomplete surveys

uk_chemical <- uk_chemical %>% filter(progress==100, finished==1)

# Count number of distinct responseid

n_distinct(uk_chemical$ID[!is.na(uk_chemical$selected)])

# Transform variables into factors and reorder features

uk_chemical$Terrorist.tactic2 <- factor(uk_chemical$Terrorist.tactic, 
                                        levels = c("Stabbing",
                                                  "Shooting", 
                                                  "Vehicle-ramming attack",
                                                  "Bombing", 
                                                  "Chemical attack" ))

uk_chemical$Motivation.for.the.terrorist.attack <- factor(uk_chemical$Motivation.for.the.terrorist.attack)

uk_chemical$Affiliation.of.the.terrorist <- factor(uk_chemical$Affiliation.of.the.terrorist)
uk_chemical$Legal.status.of.the.terrorist <- factor(uk_chemical$Legal.status.of.the.terrorist)
uk_chemical$Probability.of.the.attack <- factor(uk_chemical$Probability.of.the.attack)
uk_chemical$Number.of.deaths <- factor(uk_chemical$Number.of.deaths)

### AMCE

uk_chemical_amce <- cregg::amce(uk_chemical, 
                       selected ~ 
                         Affiliation.of.the.terrorist + 
                         Legal.status.of.the.terrorist + 
                         Motivation.for.the.terrorist.attack + 
                         Probability.of.the.attack +
                         Terrorist.tactic2*Number.of.deaths, 
                       id = ~ID)

# Transformation of the AMCE object

uk_chemical_amce_df <- as.data.frame(uk_chemical_amce)

uk_chemical_amce_df <- uk_chemical_amce_df %>% rename(term=level)
uk_chemical_amce_df <- uk_chemical_amce_df %>% rename(conf.low=lower)
uk_chemical_amce_df <- uk_chemical_amce_df %>% rename(conf.high=upper)

uk_chemical_amce_df$conf.low <- na.fill0(uk_chemical_amce_df$conf.low, 0)
uk_chemical_amce_df$conf.high <- na.fill0(uk_chemical_amce_df$conf.high, 0)

# Creating graph

# Terror tactic

uk_chemical_amce_df_tactic <- uk_chemical_amce_df %>% filter(feature=="Terrorist.tactic2")


tactic_chemical_plot <- ggcoef(uk_chemical_amce_df_tactic, vline_color = "black", conf.int = TRUE,
                      mapping = aes(x = estimate, y = term), size = 4,
                      vline_linetype =  "solid", errorbar_color = "gray30", errorbar_height = .15,
                      sort = c("ascending")) +
  theme_classic() +
  ylab("") +
  xlab("AMCE") + 
  theme(axis.text.y = element_text(family="Times New Roman", size=20)) +
  theme(text = element_text(family="Times New Roman", size=20)) + 
  xlim(-0.005, 0.2) +
  ggtitle("") +
  theme(plot.title=element_text(family="Times New Roman", size=25, vjust = 2)) +
  theme(axis.line.y = element_line(colour = "white")) +
  theme(axis.ticks.y=element_blank()) +
  geom_text(data=subset(uk_chemical_amce_df_tactic, estimate!=0), mapping=aes(label=round(estimate, 3)),
            parse = TRUE, color="black", size=4.5, check_overlap = TRUE, 
            vjust = -1.0)

#### FIGURE 7

ggsave(tactic_chemical_plot,
       file = "figures/figure7.png",
       width = 6, 
       height = 5, 
       dpi = 350, 
       units = "in", 
       device='png')
