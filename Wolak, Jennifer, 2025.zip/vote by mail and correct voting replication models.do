* The Effects of Voting by Mail on Correct Voting
* Jennifer Wolak and Carey Stapleton
* Political Behavior

* Replication models


* Table 1: Correct Voting by Voting Method
*-------------------------------------------------------------------------------

logit corrvtws vvabsent vvearly polint know educ spid ideo7m female black latino age if vvoted==1 [pweight=V200010b], cluster(srfips)


* Table 2: Effects of Voting by Mail, Coarsened Exact Matching and Entropy Balancing
*-------------------------------------------------------------------------------

* coarsened exact matching

imb polint know educ spid ideo7m if vvoted==1, treatment(vvabsent)
cem polint know educ spid ideo7m if vvoted==1, treatment(vvabsent)
regress corrvtws vvabsent [iweight=cem_weights] if vvoted==1

imb educ female black latino age if vvoted==1, treatment(vvabsent)
cem educ female black latino age if vvoted==1, treatment(vvabsent)
regress corrvtws vvabsent [iweight=cem_weights] if vvoted==1

imb polint know educ spid ideo7m female black latino age if vvoted==1, treatment(vvabsent)
cem polint know educ spid ideo7m female black latino age if vvoted==1, treatment(vvabsent)
regress corrvtws vvabsent [iweight=cem_weights] if vvoted==1

* entropy balancing

ebalance vvabsent polint know educ spid ideo7m female black latino asian age if vvoted==1, targets(2 2 2 2 2 1 1 1 1 2) 
svyset [pw=_webal]
svy: regress corrvtws vvabsent if vvoted==1 

ebalance vvabsent polint carep know educ ineff exeff ptalkd pid spid ideo7m issuesort covidvote ///
vvoted16 female black latino asian age if vvoted==1, targets(2 2 2 2 2 2 2 1 2 2 2 2 1 1 1 1 1 2) 
svyset [pw=_webal] 
svy: regress corrvtws vvabsent if vvoted==1 

ebalance vvabsent polint carep know educ ineff exeff ptalkd pid spid ideo7m issuesort covidvote ///
vvoted16 female black latino asian age fcookc pcomp20 mbst vbmlonga epi20 covicovid if vvoted==1, ///
targets(2 2 2 2 2 2 2 1 2 2 2 2 1 1 1 1 1 2 2 2 2 2 2 2) 
svyset [pw=_webal] 
svy: regress corrvtws vvabsent if vvoted==1 


* Table 3: State Access to Vote-by-Mail and the Effects on Voting by Mail and Correct Voting
*-------------------------------------------------------------------------------

* State mailed ballots to registered voters

ebalance vvabsent polint carep know educ ineff exeff ptalkd pid spid ideo7m issuesort covidvote ///
vvoted16 female black latino age if vvoted==1, targets(2 2 2 2 2 2 2 1 2 2 2 2 1 1 1 1 2) 
svyset [pw=_webal] 

medeff (probit vvabsent mbst) (probit corrvtws mbst vvabsent) ///
[pweight=_webal], treat(mbst) mediate(vvabsent) vce(cluster srfips)

* State score on accessibility of vote-by-mail

ebalance vvabsent polint carep know educ ineff exeff ptalkd pid spid ideo7m issuesort covidvote ///
vvoted16 female black latino age if vvoted==1, targets(2 2 2 2 2 2 2 1 2 2 2 2 1 1 1 1 2) 
svyset [pw=_webal] 

medeff (probit vvabsent vbmlonga) (probit corrvtws vbmlonga vvabsent) ///
[pweight=_webal], treat(vbmlonga) mediate(vvabsent) vce(cluster srfips)


